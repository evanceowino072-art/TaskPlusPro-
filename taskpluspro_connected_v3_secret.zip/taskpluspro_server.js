// TaskPlusPro (TPP) server foundation.
// Install: npm i express cors dotenv @supabase/supabase-js
// Run: node taskpluspro_server.js

import express from 'express';
import cors from 'cors';
import 'dotenv/config';
import { createClient } from '@supabase/supabase-js';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const required = ['SUPABASE_URL','SUPABASE_SERVICE_ROLE_KEY'];
for (const key of required) if (!process.env[key]) console.warn(`Missing environment variable: ${key}`);

const supabase = createClient(process.env.SUPABASE_URL || '', process.env.SUPABASE_SERVICE_ROLE_KEY || '', {
  auth: { autoRefreshToken: false, persistSession: false }
});

const app = express();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
app.use(express.static(__dirname));
app.use(cors({ origin: process.env.CORS_ORIGIN || true }));
app.use(express.json({ limit: '2mb' }));

app.get('/', (_req,res) => res.sendFile(path.join(__dirname, 'taskpluspro_tpp_v3.html')));

app.get('/api/health', (_req,res) => res.json({ ok:true, service:'TaskPlusPro API' }));

async function authUser(req,res,next) {
  const token = req.headers.authorization?.replace(/^Bearer\s+/i,'');
  if (!token) return res.status(401).json({ error:'Authentication required' });
  const { data, error } = await supabase.auth.getUser(token);
  if (error || !data.user) return res.status(401).json({ error:'Invalid session' });
  req.user = data.user;
  next();
}

app.post('/api/profile/referral', authUser, async (req,res) => {
  const code = String(req.body?.referral_code || '').trim().toUpperCase();
  if (!code) return res.json({linked:false});
  const { data: referrer } = await supabase.from('profiles').select('id').eq('referral_code',code).maybeSingle();
  if (!referrer || referrer.id === req.user.id) return res.status(400).json({error:'Invalid referral code'});
  const { data: existing } = await supabase.from('referrals').select('id').eq('referred_id',req.user.id).maybeSingle();
  if (existing) return res.json({linked:true,already_linked:true});
  const { data,error } = await supabase.from('referrals').insert({referrer_id:referrer.id,referred_id:req.user.id,referral_code:code}).select().single();
  if (error) return res.status(400).json({error:error.message});
  const { error: profileError } = await supabase.from('profiles').update({referred_by:referrer.id,updated_at:new Date().toISOString()}).eq('id',req.user.id);
  if (profileError) return res.status(500).json({error:profileError.message});
  res.status(201).json({linked:true,referral:data});
});

app.get('/api/me', authUser, async (req,res) => {
  const { data, error } = await supabase.from('profiles').select('*').eq('id', req.user.id).single();
  if (error) return res.status(500).json({ error:error.message });
  res.json(data);
});

app.get('/api/tasks', authUser, async (req,res) => {
  const category = req.query.category;
  let q = supabase.from('tasks').select('*').eq('status','open').order('created_at',{ascending:false});
  if (category && category !== 'All') q = q.eq('category', category);
  const { data,error } = await q;
  if (error) return res.status(500).json({error:error.message});
  res.json(data);
});

app.post('/api/tasks', authUser, async (req,res) => {
  const { title, description, category, reward, currency='USD', deadline, max_workers } = req.body;
  if (!title || !description || !category || !reward) return res.status(400).json({error:'Missing required task fields'});
  const { data: profile } = await supabase.from('profiles').select('role').eq('id',req.user.id).single();
  if (!profile || !['client','admin'].includes(profile.role)) return res.status(403).json({error:'Client account required'});
  const { data,error } = await supabase.from('tasks').insert({client_id:req.user.id,title,description,category,reward,currency,deadline,max_workers,status:'draft'}).select().single();
  if (error) return res.status(400).json({error:error.message});
  res.status(201).json(data);
});

app.post('/api/tasks/:id/claim', authUser, async (req,res) => {
  const { data: profile } = await supabase.from('profiles').select('membership_status,role').eq('id',req.user.id).single();
  if (!profile || profile.role !== 'member' || profile.membership_status !== 'active') return res.status(403).json({error:'Active member account required'});
  const { data,error } = await supabase.from('task_claims').insert({task_id:req.params.id,member_id:req.user.id}).select().single();
  if (error) return res.status(400).json({error:error.message});
  res.status(201).json(data);
});

app.post('/api/tasks/:id/submissions', authUser, async (req,res) => {
  const { file_url, file_name, file_type, notes } = req.body;
  const { data,error } = await supabase.from('submissions').insert({task_id:req.params.id,member_id:req.user.id,file_url,file_name,file_type,notes}).select().single();
  if (error) return res.status(400).json({error:error.message});
  res.status(201).json(data);
});

app.post('/api/withdrawals', authUser, async (req,res) => {
  const { amount,currency='USD',method,destination } = req.body;
  if (!amount || !method || !destination) return res.status(400).json({error:'Missing withdrawal details'});
  const { data,error } = await supabase.from('withdrawals').insert({user_id:req.user.id,amount,currency,method,destination}).select().single();
  if (error) return res.status(400).json({error:error.message});
  res.status(201).json(data);
});

app.get('/api/referrals', authUser, async (req,res) => {
  const { data, error } = await supabase.from('referrals').select('*').eq('referrer_id', req.user.id).order('created_at',{ascending:false});
  if (error) return res.status(500).json({error:error.message});
  const paid = (data || []).filter(r => r.eligible).length;
  res.json({ referrals:data || [], paid_referrals:paid, bonus_total:paid * 2, remaining:Math.max(0,20-paid) });
});

app.get('/api/wallet', authUser, async (req,res) => {
  const { data, error } = await supabase.from('transactions').select('*').eq('user_id', req.user.id).order('created_at',{ascending:false});
  if (error) return res.status(500).json({error:error.message});
  const confirmed = (data || []).filter(t => t.status === 'confirmed');
  const available = confirmed.reduce((sum,t) => {
    if (['task_earning','referral_bonus','adjustment','refund'].includes(t.type)) return sum + Number(t.amount);
    if (t.type === 'withdrawal') return sum - Number(t.amount);
    return sum;
  }, 0);
  res.json({available_balance:Math.max(0,Number(available.toFixed(2))), transactions:data || []});
});

app.post('/api/membership/start', authUser, async (req,res) => {
  const { provider='mpesa', currency='USD' } = req.body || {};
  const { data: profile } = await supabase.from('profiles').select('membership_status').eq('id',req.user.id).single();
  if (!profile) return res.status(404).json({error:'Profile not found'});
  if (profile.membership_status === 'active') return res.json({active:true,message:'Membership already active'});
  const { data, error } = await supabase.from('transactions').insert({user_id:req.user.id,type:'membership',amount:5,currency,status:'pending',provider,metadata:{membership_fee_usd:5}}).select().single();
  if (error) return res.status(400).json({error:error.message});
  res.status(201).json({transaction:data,payment_required:true,message:'Membership payment created. Complete payment through the configured provider.'});
});

// Payment webhooks must be verified with the provider's signature before calling
// this handler. Keep provider-specific signature verification in a separate module.
app.post('/api/payments/webhook', async (req,res) => {
  // TODO: verify provider signature, idempotency, amount/currency, then:
  // 1) create/confirm a membership transaction
  // 2) activate the member
  // 3) create/confirm referral eligibility where applicable
  res.status(501).json({error:'Payment webhook provider is not configured yet'});
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`TaskPlusPro API listening on port ${port}`));
