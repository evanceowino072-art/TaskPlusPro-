# TaskPlusPro connected package

This package connects the TPP v3 frontend to the TPP API and Supabase Auth/database foundation.

## Setup
1. Create a Supabase project.
2. Run `taskpluspro_backend_schema.sql` in the Supabase SQL editor.
3. Copy `.env.example` to `.env` and add your server-side credentials privately.
4. Set `TPP_SUPABASE_URL`, `TPP_SUPABASE_ANON_KEY`, and optionally `TPP_API_BASE` as browser configuration when deploying the frontend, or inject them before serving the HTML.
5. Run `npm install` then `npm start`.
6. Open the server URL. The server serves `taskpluspro_tpp_v3.html` and `/api/*`.

## Secret handling
- Do not put phone numbers, account IDs, API secrets, passwords, private keys, or payment credentials in the README or browser code.
- Keep `.env` private and never commit it to GitHub or upload it publicly.
- Never put `SUPABASE_SERVICE_ROLE_KEY`, payment secrets, M-Pesa passkey, SMTP password, or JWT secret in browser code.
- The `.env.example` file contains placeholders only; enter real credentials only in your private `.env` or hosting provider's secret/environment-variable settings.

## Payments
- The $5 membership transaction endpoint is connected, but payment-provider webhook verification must be configured with real provider credentials before money is accepted or membership is activated.
- Test payments in sandbox before production.
