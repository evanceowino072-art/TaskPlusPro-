-- TaskPlusPro (TPP) production database schema
-- PostgreSQL / Supabase

create extension if not exists pgcrypto;

create type public.account_role as enum ('member','client','admin');
create type public.membership_status as enum ('pending','active','suspended','cancelled');
create type public.task_status as enum ('draft','open','claimed','in_review','completed','cancelled');
create type public.submission_status as enum ('submitted','in_review','approved','rejected');
create type public.transaction_type as enum ('membership','task_earning','referral_bonus','withdrawal','refund','adjustment');
create type public.transaction_status as enum ('pending','confirmed','failed','reversed');
create type public.withdrawal_status as enum ('requested','processing','paid','rejected','failed');

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  role public.account_role not null default 'member',
  membership_status public.membership_status not null default 'pending',
  referral_code text unique,
  referred_by uuid references public.profiles(id),
  country_code text,
  preferred_language text not null default 'en',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.tasks (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.profiles(id) on delete restrict,
  title text not null,
  description text not null,
  category text not null,
  reward numeric(12,2) not null check (reward >= 0),
  currency text not null default 'USD',
  deadline timestamptz,
  status public.task_status not null default 'draft',
  max_workers integer check (max_workers is null or max_workers > 0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.task_claims (
  id uuid primary key default gen_random_uuid(),
  task_id uuid not null references public.tasks(id) on delete cascade,
  member_id uuid not null references public.profiles(id) on delete restrict,
  claimed_at timestamptz not null default now(),
  unique(task_id, member_id)
);

create table if not exists public.submissions (
  id uuid primary key default gen_random_uuid(),
  task_id uuid not null references public.tasks(id) on delete cascade,
  member_id uuid not null references public.profiles(id) on delete restrict,
  file_url text,
  file_name text,
  file_type text,
  notes text,
  status public.submission_status not null default 'submitted',
  reviewer_notes text,
  created_at timestamptz not null default now(),
  reviewed_at timestamptz,
  unique(task_id, member_id)
);

create table if not exists public.transactions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete restrict,
  type public.transaction_type not null,
  amount numeric(12,2) not null,
  currency text not null default 'USD',
  status public.transaction_status not null default 'pending',
  provider text,
  provider_reference text,
  related_user_id uuid references public.profiles(id),
  related_task_id uuid references public.tasks(id),
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  confirmed_at timestamptz
);

create table if not exists public.withdrawals (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete restrict,
  amount numeric(12,2) not null check (amount > 0),
  currency text not null default 'USD',
  method text not null,
  destination text not null,
  status public.withdrawal_status not null default 'requested',
  provider_reference text,
  notes text,
  created_at timestamptz not null default now(),
  processed_at timestamptz
);

create table if not exists public.referrals (
  id uuid primary key default gen_random_uuid(),
  referrer_id uuid not null references public.profiles(id) on delete restrict,
  referred_id uuid not null unique references public.profiles(id) on delete restrict,
  referral_code text not null,
  eligible boolean not null default false,
  bonus_amount numeric(12,2) not null default 2.00 check (bonus_amount = 2.00),
  bonus_transaction_id uuid references public.transactions(id),
  created_at timestamptz not null default now(),
  eligible_at timestamptz
);

create unique index if not exists one_bonus_per_referrer_referred
  on public.referrals(referrer_id, referred_id);

create or replace function public.generate_referral_code()
returns text language plpgsql as $$
declare code text;
begin
  loop
    code := 'TPP-' || upper(substr(encode(gen_random_bytes(5),'hex'),1,8));
    exit when not exists (select 1 from public.profiles where referral_code = code);
  end loop;
  return code;
end $$;

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, full_name, referral_code)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name','TPP Member'), public.generate_referral_code())
  on conflict (id) do nothing;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.tasks enable row level security;
alter table public.task_claims enable row level security;
alter table public.submissions enable row level security;
alter table public.transactions enable row level security;
alter table public.withdrawals enable row level security;
alter table public.referrals enable row level security;

create policy "profiles own read" on public.profiles for select using (auth.uid() = id);
create policy "profiles own update" on public.profiles for update using (auth.uid() = id);
create policy "open tasks visible" on public.tasks for select using (status = 'open' or client_id = auth.uid());
create policy "clients create tasks" on public.tasks for insert with check (client_id = auth.uid());
create policy "clients update own tasks" on public.tasks for update using (client_id = auth.uid());
create policy "members see own claims" on public.task_claims for select using (member_id = auth.uid());
create policy "members claim tasks" on public.task_claims for insert with check (member_id = auth.uid());
create policy "submission owner read" on public.submissions for select using (member_id = auth.uid() or exists (select 1 from public.tasks t where t.id = task_id and t.client_id = auth.uid()));
create policy "member submits work" on public.submissions for insert with check (member_id = auth.uid());
create policy "own transactions read" on public.transactions for select using (user_id = auth.uid());
create policy "own withdrawals read" on public.withdrawals for select using (user_id = auth.uid());
create policy "member requests withdrawal" on public.withdrawals for insert with check (user_id = auth.uid());
create policy "own referrals read" on public.referrals for select using (referrer_id = auth.uid() or referred_id = auth.uid());

-- Server-side service role is used for payment webhooks, referral crediting,
-- wallet ledger updates, reviews, and withdrawals. Those operations must not
-- be exposed through the anon key.
